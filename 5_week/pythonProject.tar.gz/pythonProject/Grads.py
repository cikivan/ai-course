# generate 2D meshgrid, how many points we want in x or y direction
import numpy as np
nx, ny = (100, 100)

# nx points in  0-10 range
x = np.linspace(0, 10, nx)
y = np.linspace(0, 10, ny)

# combine
xv, yv = np.meshgrid(x,y)


# define function to plot
def f(x,y):
    return x * (y**2)

z = f(xv, yv)
print(z)